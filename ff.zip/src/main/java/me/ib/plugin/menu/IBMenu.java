package me.ib.plugin.menu;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;

public class IBMenu {
    public static void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, "§8IB » Tag Menü");

        inv.setItem(11, item(Material.RED_WOOL, "§cKırmızı"));
        inv.setItem(13, item(Material.GREEN_WOOL, "§aYeşil"));
        inv.setItem(15, item(Material.BLUE_WOOL, "§9Mavi"));

        player.openInventory(inv);
    }

    private static ItemStack item(Material m, String name) {
        ItemStack i = new ItemStack(m);
        ItemMeta meta = i.getItemMeta();
        meta.setDisplayName(name);
        i.setItemMeta(meta);
        return i;
    }
}

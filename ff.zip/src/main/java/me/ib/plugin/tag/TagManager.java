package me.ib.plugin.tag;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

public class TagManager {
    private final Scoreboard board = Bukkit.getScoreboardManager().getMainScoreboard();

    public void setTag(Player player, String tag) {
        Team team = board.getTeam(player.getName());
        if (team == null) team = board.registerNewTeam(player.getName());
        team.setPrefix("§f[" + tag + "] ");
        team.addEntry(player.getName());
        player.setScoreboard(board);
    }
}

package me.ib.plugin;

import me.ib.plugin.commands.IBCommand;
import me.ib.plugin.tag.TagManager;
import org.bukkit.plugin.java.JavaPlugin;

public class IB extends JavaPlugin {
    private TagManager tagManager;

    @Override
    public void onEnable() {
        tagManager = new TagManager();
        getCommand("ib").setExecutor(new IBCommand(this));
    }

    public TagManager getTagManager() {
        return tagManager;
    }
}

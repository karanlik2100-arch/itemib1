package me.ib.plugin.commands;

import me.ib.plugin.IB;
import me.ib.plugin.menu.IBMenu;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class IBCommand implements CommandExecutor {
    private final IB plugin;

    public IBCommand(IB plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;

        if (args.length == 1 && args[0].equalsIgnoreCase("menu")) {
            IBMenu.open(player);
            return true;
        }

        if (args.length >= 2 && args[0].equalsIgnoreCase("tag")) {
            String tag = String.join(" ", args).substring(4);
            plugin.getTagManager().setTag(player, tag);
            player.sendMessage("§aTag ayarlandı!");
            return true;
        }
        return true;
    }
}
